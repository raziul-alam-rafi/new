# Starlink Direct-to-Cell — Bangla motion graphics (Remotion)

    npm install
    npx remotion studio
    npx remotion render src/index.ts Main out/video.mp4

- Composition id: `Main` · entry: `src/index.ts` · 1920×1080 · 30 fps · 2065 frames (68.83 s, from the SRT)
- Optional: put the narration at `public/voiceover.mp3` → plays in Studio preview only (never in render). Flag: `src/config.ts`
- SFX: `public/sfx/*.wav` (regenerate: `npm run sfx`). Timing: `script.srt` → `npm run cues` → `src/cues.ts`
- Font Hind Siliguri loads via `@remotion/google-fonts` (needs internet on first Studio/render run).
