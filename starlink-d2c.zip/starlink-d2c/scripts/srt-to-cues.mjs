// script.srt  →  src/cues.ts   (SRT is the single source of timing)
import { readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const raw = readFileSync(join(root, "script.srt"), "utf8").replace(/\r/g, "").replace(/^\uFEFF/, "");

const toSec = (t) => {
  const [h, m, rest] = t.trim().split(":");
  const [s, ms] = rest.split(",");
  return Math.round((Number(h) * 3600 + Number(m) * 60 + Number(s)) * 1000 + Number(ms)) / 1000;
};

const cues = raw
  .split(/\n\s*\n/)
  .map((b) => b.trim())
  .filter(Boolean)
  .map((block) => {
    const lines = block.split("\n");
    const n = Number(lines[0]);
    const [a, b] = lines[1].split("-->");
    return { n, start: toSec(a), end: toSec(b), text: lines.slice(2).join(" ").replace(/\s+/g, " ").trim() };
  });

const out =
  "// AUTO-GENERATED from script.srt by scripts/srt-to-cues.mjs — do not edit by hand.\n" +
  "export type Cue = { n: number; start: number; end: number; text: string };\n" +
  "export const cues: Cue[] = " + JSON.stringify(cues, null, 2) + ";\n";
writeFileSync(join(root, "src", "cues.ts"), out);
console.log(`cues.ts written: ${cues.length} cues, ends at ${cues.at(-1).end}s`);
