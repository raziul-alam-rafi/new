// Synthesises the tiny SFX kit into public/sfx/*.wav  (16-bit mono, 44.1 kHz).
// No downloads, fully deterministic.   Run:  node scripts/make-sfx.mjs
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const SR = 44100;
const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const outDir = join(root, "public", "sfx");
mkdirSync(outDir, { recursive: true });

// ---------- helpers ----------
let seed = 1337;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
const buf = (sec) => new Float32Array(Math.ceil(sec * SR));

// RBJ biquad. type: lp | hp | bp
const biquad = (x, type, f0, q = 0.707) => {
  const w0 = (2 * Math.PI * f0) / SR;
  const cos = Math.cos(w0), alpha = Math.sin(w0) / (2 * q);
  let b0, b1, b2;
  if (type === "lp") { b0 = (1 - cos) / 2; b1 = 1 - cos; b2 = (1 - cos) / 2; }
  else if (type === "hp") { b0 = (1 + cos) / 2; b1 = -(1 + cos); b2 = (1 + cos) / 2; }
  else { b0 = alpha; b1 = 0; b2 = -alpha; }
  const a0 = 1 + alpha, a1 = -2 * cos, a2 = 1 - alpha;
  const y = new Float32Array(x.length);
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  for (let i = 0; i < x.length; i++) {
    const v = (b0 * x[i] + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2) / a0;
    x2 = x1; x1 = x[i]; y2 = y1; y1 = v; y[i] = v;
  }
  return y;
};

// time-varying band-pass (sweeping centre frequency) — for whooshes
const sweepBP = (x, fOf, q) => {
  const y = new Float32Array(x.length);
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  for (let i = 0; i < x.length; i++) {
    const f0 = fOf(i / x.length);
    const w0 = (2 * Math.PI * f0) / SR;
    const cos = Math.cos(w0), alpha = Math.sin(w0) / (2 * q);
    const b0 = alpha, b2 = -alpha, a0 = 1 + alpha, a1 = -2 * cos, a2 = 1 - alpha;
    const v = (b0 * x[i] + b2 * x2 - a1 * y1 - a2 * y2) / a0;
    x2 = x1; x1 = x[i]; y2 = y1; y1 = v; y[i] = v;
  }
  return y;
};

// very small, dark reverb: a few low-passed echo taps
const tinyReverb = (x, mix = 0.16) => {
  const taps = [[0.021, 0.5], [0.037, 0.38], [0.058, 0.26], [0.083, 0.16]];
  const tail = Math.ceil(0.09 * SR);
  const y = new Float32Array(x.length + tail);
  y.set(x);
  const wet = biquad(x, "lp", 2800);
  for (const [d, g] of taps) {
    const off = Math.round(d * SR);
    for (let i = 0; i < wet.length; i++) y[i + off] += wet[i] * g * mix * 2;
  }
  return y;
};

const fade = (x, outSec = 0.02) => {
  const n = Math.min(x.length, Math.round(outSec * SR));
  for (let i = 0; i < n; i++) x[x.length - 1 - i] *= i / n;
  return x;
};

// ---------- sounds ----------
// soft pop: sine with fast downward pitch glide + tiny envelope
const pop = () => {
  const x = buf(0.2);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 170 + 360 * Math.exp(-t / 0.028);
    ph += (2 * Math.PI * f) / SR;
    const env = Math.min(1, t / 0.004) * Math.exp(-t / 0.05);
    x[i] = (Math.sin(ph) + 0.18 * Math.sin(2 * ph)) * env;
  }
  return tinyReverb(biquad(x, "lp", 4200));
};

// crisp click: short high-passed noise burst + faint tick
const click = () => {
  const x = buf(0.09);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const env = Math.min(1, t / 0.0008) * Math.exp(-t / 0.011);
    x[i] = rnd() * env + 0.35 * Math.sin(2 * Math.PI * 2100 * t) * Math.exp(-t / 0.006);
  }
  return tinyReverb(biquad(biquad(x, "hp", 2600), "lp", 7000), 0.1);
};

// soft whoosh (text entry): band-pass noise sweeping up, smooth in/out
const whoosh = () => {
  const dur = 0.5;
  const n = buf(dur);
  for (let i = 0; i < n.length; i++) n[i] = rnd();
  const y = sweepBP(n, (p) => 380 * Math.pow(2400 / 380, p), 1.1);
  for (let i = 0; i < y.length; i++) {
    const p = i / y.length;
    y[i] *= Math.pow(Math.sin(Math.PI * Math.pow(p, 0.8)), 2);
  }
  return tinyReverb(biquad(y, "lp", 5500), 0.12);
};

// swipe (scene transition): band-pass noise sweeping down, slightly longer
const swipe = () => {
  const n = buf(0.62);
  for (let i = 0; i < n.length; i++) n[i] = rnd();
  const y = sweepBP(n, (p) => 3000 * Math.pow(520 / 3000, p), 0.95);
  for (let i = 0; i < y.length; i++) {
    const p = i / y.length;
    y[i] *= Math.pow(Math.sin(Math.PI * Math.pow(p, 0.65)), 2);
  }
  return tinyReverb(biquad(y, "lp", 5200), 0.1);
};

// chime / pluck: soft overtones, short decay
const chime = () => {
  const x = buf(0.38);
  const parts = [[880, 1], [1318.5, 0.45], [1760, 0.22], [2637, 0.08]];
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    let v = 0;
    parts.forEach(([f, g], k) => { v += g * Math.sin(2 * Math.PI * f * t) * Math.exp(-t / (0.14 - k * 0.02)); });
    x[i] = v * Math.min(1, t / 0.004);
  }
  return tinyReverb(biquad(x, "lp", 6000));
};

// soft thud (hook / key message): low sine glide, restrained
const thud = () => {
  const x = buf(0.3);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 52 + 70 * Math.exp(-t / 0.05);
    ph += (2 * Math.PI * f) / SR;
    x[i] = Math.sin(ph) * Math.min(1, t / 0.007) * Math.exp(-t / 0.085);
  }
  return tinyReverb(biquad(x, "lp", 520), 0.08);
};

// ---------- level matching + write ----------
// every file is peak-normalised to the same level (-0.9 dBFS-ish headroom: 0.9),
// per-event loudness is then set once, in code, with volumes in the 0.2–0.35 range.
const PEAK_TARGET = 0.9;

const writeWav = (name, x) => {
  fade(x, 0.02);
  let peak = 0;
  for (const v of x) peak = Math.max(peak, Math.abs(v));
  const g = PEAK_TARGET / peak;
  const pcm = Buffer.alloc(44 + x.length * 2);
  pcm.write("RIFF", 0); pcm.writeUInt32LE(36 + x.length * 2, 4); pcm.write("WAVE", 8);
  pcm.write("fmt ", 12); pcm.writeUInt32LE(16, 16); pcm.writeUInt16LE(1, 20); pcm.writeUInt16LE(1, 22);
  pcm.writeUInt32LE(SR, 24); pcm.writeUInt32LE(SR * 2, 28); pcm.writeUInt16LE(2, 32); pcm.writeUInt16LE(16, 34);
  pcm.write("data", 36); pcm.writeUInt32LE(x.length * 2, 40);
  for (let i = 0; i < x.length; i++) {
    const v = Math.max(-1, Math.min(1, x[i] * g));
    pcm.writeInt16LE(Math.round(v * 32767), 44 + i * 2);
  }
  writeFileSync(join(outDir, `${name}.wav`), pcm);
};

const kit = { pop, click, whoosh, swipe, chime, thud };
for (const [name, fn] of Object.entries(kit)) writeWav(name, fn());
console.log("SFX written to", outDir, Object.keys(kit).join(", "));
