// sfx.ts — the limited SFX set (6 sounds) and where each plays. Frames come from events.ts (SRT-derived).
// Rules: only main entries, card / logo reveals, key messages and scene transitions — never every stagger.
import { E } from "./events";
import { FPS, SCENES } from "./timeline";

export type SfxKind = "pop" | "click" | "whoosh" | "swipe" | "chime" | "thud";

/** file length in seconds (checked by scripts/make-sfx.mjs + verification) */
export const SFX_LEN: Record<SfxKind, number> = { pop: 0.29, click: 0.18, whoosh: 0.59, swipe: 0.71, chime: 0.47, thud: 0.39 };
/** one calm level per kind (0.2–0.35) so the narration is never masked */
export const SFX_VOL: Record<SfxKind, number> = { pop: 0.3, click: 0.3, whoosh: 0.28, swipe: 0.26, chime: 0.28, thud: 0.32 };

export type SfxEvent = { f: number; kind: SfxKind; vol?: number; rate?: number };

// sound lands 2–3 frames BEFORE the visual settles
const L = 2;
const at = (abs: number, kind: SfxKind, rate = 1, vol?: number): SfxEvent => ({ f: Math.max(0, abs - L), kind, rate, vol });

export const SFX: SfxEvent[] = [
  // scene transitions (outgoing → incoming)
  ...SCENES.slice(1).map((s, i) => at(s.from + 1, "swipe", 0.96 + (i % 3) * 0.04)),

  // S1 — hook, phone / tower reveals, the break
  at(E.s1.title, "thud", 1),
  at(E.s1.title + 3, "whoosh", 1),
  at(E.s1.phone, "pop", 1.0),
  at(E.s1.tower, "pop", 0.94),
  at(E.s1.link, "chime", 1.04),
  at(E.s1.breakUp, "whoosh", 0.92),
  at(E.s1.noTower, "click", 0.96),

  // S2 — kinetic type
  at(E.s2.statement + 4, "pop", 0.98),
  at(E.s2.d2c, "thud", 0.9),
  at(E.s2.d2c + 2, "whoosh", 1.04),
  at(E.s2.starlink + 3, "chime", 1),

  // S3 — satellite + cards
  at(E.s3.title, "whoosh", 1),
  at(E.s3.beam, "pop", 1.04),
  at(E.s3.card1, "pop", 1),
  at(E.s3.card2, "pop", 0.95),

  // S4 — eNodeB chip
  at(E.s4.kicker, "pop", 1.06),
  at(E.s4.chip, "chime", 1.02),
  at(E.s4.statement, "whoosh", 0.98),

  // S5 — antenna lens
  at(E.s5.phone + 2, "pop", 0.98),
  at(E.s5.lens, "pop", 1.06),
  at(E.s5.label, "whoosh", 1.02),

  // S6 — key message + before/after
  at(E.s6.key, "thud", 1.1),
  at(E.s6.caption, "whoosh", 1),
  at(E.s6.split, "whoosh", 0.96),
  at(E.s6.no, "click", 0.94),
  at(E.s6.no + 8, "click", 1.06),

  // S7 — recap grid + sign-off
  at(E.s7.title, "whoosh", 1),
  at(E.s7.card1, "pop", 1.02),
  at(E.s7.card2, "pop", 0.98),
  at(E.s7.card3, "pop", 1.04),
  at(E.s7.card4, "pop", 1),
  at(E.s7.banner, "chime", 0.96),
  at(E.s7.end, "chime", 1.06),
];

export const sfxDurationFrames = (e: SfxEvent) => Math.ceil((SFX_LEN[e.kind] / (e.rate ?? 1)) * FPS) + 3;
