// timeline.ts — EVERY timing in the video is derived from the SRT cues (cues.ts).
// Nothing is hand-placed: scene bounds come from cue bounds, in-scene events come from
// where a word sits inside its cue (proportional to character position) or from
// even spacing across a cue.
import { cues } from "./cues";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
/** visuals land this many frames BEFORE the matching words (4–6 frames) */
export const LEAD = 5;

const frames = (s: number) => Math.round(s * FPS);
const cue = (n: number) => {
  const c = cues[n - 1];
  if (!c) throw new Error(`cue ${n} not in SRT`);
  return c;
};

export const cueStart = (n: number) => frames(cue(n).start);
export const cueEnd = (n: number) => frames(cue(n).end);
export const TOTAL = frames(cues[cues.length - 1].end);

/** frame at which `needle` is spoken inside cue n (position-proportional estimate) */
export const said = (n: number, needle: string, occurrence = 0) => {
  const c = cue(n);
  let idx = -1;
  for (let i = 0; i <= occurrence; i++) {
    idx = c.text.indexOf(needle, idx + 1);
    if (idx < 0) throw new Error(`"${needle}" not found in cue ${n}: ${c.text}`);
  }
  return frames(c.start + (idx / c.text.length) * (c.end - c.start));
};
/** frame at which a visual for `needle` should land (spoken − LEAD) */
export const show = (n: number, needle: string, occurrence = 0) => said(n, needle, occurrence) - LEAD;
/** k-th of `count` equally spaced slots across cue n (for several items named in one cue) */
export const evenly = (n: number, count: number, k: number) => {
  const c = cue(n);
  return frames(c.start + ((c.end - c.start) * k) / count) - LEAD;
};
/** a cue's first frame, minus lead */
export const cueIn = (n: number) => cueStart(n) - LEAD;

// ---- scenes: boundaries sit on cue boundaries ----
const defs = [
  { id: "s1", cues: [1, 2] }, // সাধারণ নেটওয়ার্ক → টাওয়ার নেই
  { id: "s2", cues: [3] }, // নেটওয়ার্ক নেই → Direct-to-Cell · Starlink
  { id: "s3", cues: [4, 5] }, // স্যাটেলাইট = মহাকাশের টাওয়ার
  { id: "s4", cues: [6, 7] }, // eNodeB modem
  { id: "s5", cues: [8] }, // ফোনের ছোট antenna
  { id: "s6", cues: [9, 10] }, // মূল বিষয়: বিশাল antenna লাগে না
  { id: "s7", cues: [11, 12, 13] }, // recap grid
] as const;

export type SceneId = (typeof defs)[number]["id"];

export const SCENES = defs.map((d, i) => {
  const first = d.cues[0];
  const next = defs[i + 1];
  const from = i === 0 ? 0 : cueStart(first) - LEAD; // next scene enters LEAD frames early
  const to = next ? cueStart(next.cues[0]) : TOTAL;
  return { id: d.id as SceneId, from, to, duration: to - from };
});
export const scene = (id: SceneId) => SCENES.find((s) => s.id === id)!;
