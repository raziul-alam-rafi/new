// Studio-only voiceover preview. Put your narration at public/voiceover.mp3.
//  • file missing  → silently skipped
//  • enabled:false → never plays
//  • includeInRender:false (default) → NEVER included in rendered MP4 (SFX-only master)
export const PREVIEW_AUDIO = {
  enabled: true,
  src: "voiceover.mp3",
  includeInRender: false,
  volume: 1,
} as const;
