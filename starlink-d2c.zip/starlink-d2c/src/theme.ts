// theme.ts — single source of truth: colors, fonts, easings, springs, radii, shadows.
// Colour scheme: "Deep Space" (user's pick #1).
import { Easing } from "remotion";
import { loadFont } from "@remotion/google-fonts/HindSiliguri";

// Bangla-capable family with proper conjuncts. Loaded through @remotion/google-fonts
// (bundled by Remotion, no system install needed). Fallbacks keep Bangla legible if the
// font request is ever blocked.
const { fontFamily } = loadFont("normal", {
  weights: ["400", "500", "600", "700"],
  subsets: ["bengali", "latin"],
});

export const alpha = (hex: string, a: number) => {
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${a})`;
};

const colors = {
  bg: "#060B1A",
  bgAlt: "#0A1230",
  surface: "#0E1938",
  surfaceHi: "#152450",
  primary: "#4F8CFF", // THE hero colour — one focal element per frame
  accent: "#22D3EE",
  text: "#F2F6FF",
  textDim: "#9AAACB",
} as const;

export const theme = {
  colors: {
    ...colors,
    glow: alpha(colors.primary, 0.45),
    accentGlow: alpha(colors.accent, 0.35),
    line: alpha(colors.text, 0.14),
    lineSoft: alpha(colors.text, 0.08),
  },
  fonts: {
    // one family for the entire video (Bangla + Latin)
    display: `${fontFamily}, "Noto Sans Bengali", "Hind Siliguri", sans-serif`,
    body: `${fontFamily}, "Noto Sans Bengali", "Hind Siliguri", sans-serif`,
  },
  weight: { display: 700, strong: 600, body: 500 },
  // THE easing curves. Linear is forbidden.
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1), // entrances
    inOut: Easing.bezier(0.83, 0, 0.17, 1), // moves, Ken-Burns style drifts
    in: Easing.bezier(0.7, 0, 0.84, 0), // exits only
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 }, // words, UI pops
    smooth: { damping: 20, stiffness: 90, mass: 1 }, // big elements
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 }, // accents, key reveals
  },
  radius: { card: 36, small: 22, pill: 999 },
  shadow: {
    card: "0 40px 80px -24px rgba(0, 0, 0, 0.65)",
    glow: (c: string) => `0 0 60px ${alpha(c, 0.4)}, 0 0 120px ${alpha(c, 0.2)}`,
  },
  // typographic scale (px @ 1920×1080)
  size: { hero: 190, title: 104, heading: 84, label: 46, small: 38 },
  lineHeight: 1.32, // Bangla needs air for matras — never tighter
  stroke: 4, // line-icon weight
} as const;
