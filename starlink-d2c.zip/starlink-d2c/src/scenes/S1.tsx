// Scene 1 · Glossy UI diagram — সাধারণ নেটওয়ার্ক (ফোন ↔ টাওয়ার), তারপর "টাওয়ার নেই"
import React from "react";
import { AbsoluteFill } from "remotion";
import { E } from "../events";
import { alpha, theme } from "../theme";
import { Phone, Pulses, Tower, CrossIcon, quad } from "../lib/art";
import { At, Chip, Reveal, Words, breathe, floatY, useAnim } from "../lib/ui";

const c = theme.colors;
const P0: [number, number] = [560, 540];
const P1: [number, number] = [1000, 300];
const P2: [number, number] = [1430, 480];
const PATH = `M${P0[0]} ${P0[1]} Q${P1[0]} ${P1[1]} ${P2[0]} ${P2[1]}`;

export const S1: React.FC = () => {
  const { frame, since, tween, spr } = useAnim();
  const e = E.s1;

  const tBreak = since(e.breakUp);
  const broken = tween(tBreak, 0.45, 0, 1);
  const tNo = since(e.noTower);

  const linkT = since(e.link);
  const linkO = tween(linkT, 0.4, 0, 1) * (1 - broken);
  const bars = tween(linkT, 0.9, 0, 4) * (1 - broken);

  const oldTitleO = 1 - tween(tBreak, 0.25, 0, 1, theme.ease.in);
  const oldTitleY = tween(tBreak, 0.25, 0, -30, theme.ease.in);

  const groundS = tween(since(e.ground), 0.9, 0, 1);

  return (
    <AbsoluteFill>
      {/* titles */}
      <At x={960} y={64} w={1700} style={{ opacity: oldTitleO, transform: `translateY(${oldTitleY}px)` }}>
        <Words text="সাধারণ মোবাইল নেটওয়ার্ক" t={since(e.title)} per={5} hl={["নেটওয়ার্ক"]} />
      </At>
      {tBreak > 0 && (
        <At x={960} y={64} w={1700}>
          <Words text="যেখানে টাওয়ার নেই" t={tBreak - 5} per={5} hl={["টাওয়ার"]} />
        </At>
      )}

      {/* ground line */}
      <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: 0 }}>
        <line
          x1={960 - 800 * groundS} x2={960 + 800 * groundS} y1={872} y2={872}
          stroke={alpha(c.text, 0.22)} strokeWidth={2} strokeLinecap="round"
        />
        {/* radio link */}
        <g opacity={linkO}>
          <path d={PATH} fill="none" stroke={alpha(c.accent, 0.18)} strokeWidth={10} strokeLinecap="round" />
          <path d={PATH} fill="none" stroke={c.accent} strokeWidth={3} strokeLinecap="round" strokeDasharray="2 16" strokeDashoffset={-frame * 0.9} />
          {[0, 1, 2].map((i) => {
            const k = (((frame * 0.011 + i / 3) % 1) + 1) % 1;
            const tt = i === 2 ? 1 - k : k;
            const [x, y] = quad(P0, P1, P2, tt);
            return <circle key={i} cx={x} cy={y} r={9} fill={c.text} opacity={0.95} />;
          })}
        </g>
      </svg>
      {linkT > 0 && <Pulses cx={1500} cy={472} t={linkT} a0={150} a1={210} minR={90} maxR={280} count={3} period={80} sw={3} strength={linkO} />}

      {/* phone */}
      <div style={{ position: "absolute", left: 305, top: 400 + floatY(frame, 5, 100) }}>
        <Reveal t={since(e.phone)} y={60} preset="bouncy" scale={0.85}>
          <Phone w={230} bars={bars}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 18, opacity: 0.9 }}>
              <div style={{ width: 70, height: 70, borderRadius: 70, background: alpha(c.text, 0.16) }} />
              <div style={{ width: 120, height: 12, borderRadius: 6, background: alpha(c.text, 0.18) }} />
              <div style={{ width: 90, height: 12, borderRadius: 6, background: alpha(c.text, 0.12) }} />
            </div>
          </Phone>
        </Reveal>
      </div>

      {/* tower */}
      <div
        style={{
          position: "absolute", left: 1360, top: 410,
          opacity: 1 - 0.84 * broken,
          transform: `scale(${breathe(frame, 0.01, 120)})`, transformOrigin: "50% 100%",
        }}
      >
        <Reveal t={since(e.tower)} y={50} preset="smooth" scale={0.88}>
          <Tower w={280} pulse={0.7 + 0.3 * Math.sin(frame / 9)} />
        </Reveal>
      </div>

      {/* "no tower" mark */}
      {tNo > 0 && (
        <div
          style={{
            position: "absolute", left: 1500 - 90, top: 640 - 90, width: 180, height: 180,
            display: "flex", alignItems: "center", justifyContent: "center",
            transform: `scale(${0.6 + 0.4 * spr(tNo, "bouncy")})`, opacity: Math.min(1, spr(tNo, "bouncy") * 1.5),
          }}
        >
          <svg width={180} height={180} style={{ position: "absolute" }}>
            <circle cx={90} cy={90} r={84} fill={alpha(c.bg, 0.55)} stroke={alpha(c.text, 0.6)} strokeWidth={4} strokeDasharray="14 12" />
          </svg>
          <CrossIcon size={90} color={c.text} />
        </div>
      )}

      {/* labels */}
      <At x={420} y={892} w={600}>
        <Chip text="আপনার ফোন" t={since(e.phone) - 6} />
      </At>
      <At x={1500} y={892} w={700}>
        <div style={{ position: "relative", display: "flex", justifyContent: "center", width: "100%", height: 80 }}>
          <div style={{ position: "absolute", opacity: 1 - broken, transform: `translateY(${-14 * broken}px)` }}>
            <Chip text="মোবাইল টাওয়ার" t={since(e.tower) - 6} />
          </div>
          {tNo > 0 && (
            <div style={{ position: "absolute" }}>
              <Chip text="টাওয়ার নেই" t={tNo} dot={false} />
            </div>
          )}
        </div>
      </At>
      <At x={997} y={330} w={700} style={{ opacity: 1 - broken }}>
        <Chip text="রেডিও সিগন্যাল" t={linkT - 4} />
      </At>
    </AbsoluteFill>
  );
};
