// Scene 5 · Glossy UI — ফোনের ভেতরের ছোট সেলুলার antenna (zoom lens)
import React from "react";
import { AbsoluteFill } from "remotion";
import { E } from "../events";
import { alpha, theme } from "../theme";
import { AntennaIcon, Phone, Pulses, quad } from "../lib/art";
import { At, Chip, LineMask, Reveal, breathe, floatY, useAnim } from "../lib/ui";

const c = theme.colors;
const PH = { x: 560, top: 230, w: 300 }; // phone centre x, top, width
const LENS = { x: 1340, y: 430, r: 230 };
const A: [number, number] = [PH.x + 96, PH.top + 34]; // antenna spot on the phone
const B: [number, number] = [LENS.x - LENS.r + 6, LENS.y - 40];
const M: [number, number] = [(A[0] + B[0]) / 2 - 10, A[1] - 120];

export const S5: React.FC = () => {
  const { frame, since, tween, spr } = useAnim();
  const e = E.s5;
  const lensT = since(e.lens);
  const link = tween(lensT, 0.7, 0, 1);
  const lensP = spr(lensT, "bouncy");
  const radioT = since(e.radio);

  const d = `M${A[0]} ${A[1]} Q${M[0]} ${M[1]} ${B[0]} ${B[1]}`;
  const k = (((frame * 0.012) % 1) + 1) % 1;
  const [dx, dy] = quad(A, M, B, k);

  return (
    <AbsoluteFill>
      {/* phone */}
      <div style={{ position: "absolute", left: PH.x - PH.w / 2, top: PH.top + floatY(frame, 6, 110) }}>
        <Reveal t={since(e.phone)} y={70} preset="smooth" scale={0.9}>
          <Phone w={PH.w} bars={4}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 22, opacity: 0.9 }}>
              <div style={{ width: 96, height: 96, borderRadius: 96, background: alpha(c.text, 0.16) }} />
              <div style={{ width: 150, height: 14, borderRadius: 7, background: alpha(c.text, 0.18) }} />
              <div style={{ width: 110, height: 14, borderRadius: 7, background: alpha(c.text, 0.12) }} />
            </div>
          </Phone>
        </Reveal>
      </div>

      {/* connector + antenna marker */}
      <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: floatY(frame, 6, 110) * 0 }}>
        <g opacity={link}>
          <path d={d} fill="none" stroke={alpha(c.accent, 0.2)} strokeWidth={9} strokeLinecap="round" />
          <path d={d} fill="none" stroke={c.accent} strokeWidth={3} strokeLinecap="round" strokeDasharray="2 14" strokeDashoffset={-frame * 0.8} />
          <circle cx={dx} cy={dy} r={8} fill={c.text} />
          <circle cx={A[0]} cy={A[1] + floatY(frame, 6, 110)} r={13} fill="none" stroke={c.accent} strokeWidth={4} />
          <circle cx={A[0]} cy={A[1] + floatY(frame, 6, 110)} r={5} fill={c.accent} />
        </g>
      </svg>

      {/* lens */}
      <div
        style={{
          position: "absolute", left: LENS.x - LENS.r, top: LENS.y - LENS.r + floatY(frame, 7, 120, 20), width: LENS.r * 2, height: LENS.r * 2,
          opacity: Math.min(1, lensP * 1.5), transform: `scale(${0.7 + 0.3 * lensP}) scale(${breathe(frame, 0.01, 120)})`,
        }}
      >
        <div
          style={{
            width: "100%", height: "100%", borderRadius: "50%",
            background: `radial-gradient(circle at 35% 30%, ${alpha(c.surfaceHi, 0.95)}, ${alpha(c.surface, 0.95)} 70%)`,
            border: `4px solid ${c.primary}`, boxShadow: `${theme.shadow.glow(c.primary)}, inset 0 0 60px ${alpha(c.primary, 0.18)}`,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}
        >
          <AntennaIcon size={300} color={c.text} sw={4} />
        </div>
      </div>
      {radioT > 0 && <Pulses cx={LENS.x} cy={LENS.y} t={radioT} minR={LENS.r + 10} maxR={LENS.r + 150} count={3} period={80} sw={3} />}

      {/* labels */}
      <At x={LENS.x} y={730} w={900}>
        <LineMask text="ছোট সেলুলার antenna" t={since(e.label)} size={72} />
      </At>
      <At x={LENS.x} y={880} w={800}>
        <Chip text="রেডিও সিগন্যাল" t={radioT} />
      </At>
      <At x={PH.x} y={880} w={700}>
        <Chip text="ফোনে আগে থেকেই" t={since(e.phone) + 10} />
      </At>
    </AbsoluteFill>
  );
};
