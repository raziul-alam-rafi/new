// Scene 3 · Glass Cards — স্যাটেলাইট = মহাকাশের টাওয়ার; ভেতরে antenna + ইলেকট্রনিক ব্যবস্থা
import React from "react";
import { AbsoluteFill } from "remotion";
import { E } from "../events";
import { alpha, theme } from "../theme";
import { AntennaIcon, ChipIcon, Pulses, Satellite } from "../lib/art";
import { At, GlassCard, Reveal, Words, breathe, floatY, useAnim } from "../lib/ui";

const c = theme.colors;
const SX = 1450; // satellite column centre

export const S3: React.FC = () => {
  const { frame, since, tween, spr } = useAnim();
  const e = E.s3;
  const beamT = since(e.beam);
  const beam = tween(beamT, 0.8, 0, 1);
  const earthT = tween(since(e.sat), 1.1, 0, 1);

  return (
    <AbsoluteFill>
      {/* earth limb */}
      <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: 0, opacity: earthT, transform: `translateY(${(1 - earthT) * 120}px)` }}>
        <defs>
          <radialGradient id="earthFill" cx="50%" cy="0%" r="75%">
            <stop offset="0" stopColor={alpha(c.primary, 0.32)} />
            <stop offset="1" stopColor={c.bg} />
          </radialGradient>
          <linearGradient id="beamFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={alpha(c.accent, 0.38)} />
            <stop offset="1" stopColor={alpha(c.accent, 0.02)} />
          </linearGradient>
        </defs>
        <circle cx={SX} cy={1960} r={1160} fill="url(#earthFill)" stroke={alpha(c.accent, 0.55)} strokeWidth={3} />
        <circle cx={SX} cy={1960} r={1182} fill="none" stroke={alpha(c.accent, 0.12)} strokeWidth={14} />
        {/* beam */}
        <polygon
          points={`${SX},560 ${SX - 40 - 230 * beam},800 ${SX + 40 + 230 * beam},800`}
          fill="url(#beamFill)" opacity={beam}
        />
        {/* a few phones on the ground inside the beam */}
        {[-150, -40, 80, 170].map((dx, i) => (
          <circle key={i} cx={SX + dx} cy={808 + Math.abs(dx) * 0.05} r={7} fill={c.text} opacity={beam * (0.55 + 0.45 * Math.sin(frame / 12 + i * 2))} />
        ))}
      </svg>
      {beamT > 0 && <Pulses cx={SX} cy={552} t={beamT} a0={62} a1={118} minR={40} maxR={250} count={3} period={75} sw={3} />}

      {/* satellite */}
      <div style={{ position: "absolute", left: SX - 280, top: 190 + floatY(frame, 8, 120) }}>
        <Reveal t={since(e.sat)} y={-80} x={80} preset="smooth" scale={0.8}>
          <div style={{ transform: `rotate(-9deg) scale(${breathe(frame, 0.012, 140)})` }}>
            <Satellite w={560} bodyGlow />
          </div>
        </Reveal>
      </div>

      {/* title + cards */}
      <At x={120} y={96} w={1000} align="flex-start">
        <Words text="মহাকাশে মোবাইল টাওয়ার" t={since(e.title)} per={5} size={116} hl={["টাওয়ার"]} align="flex-start" />
      </At>

      <div style={{ position: "absolute", left: 120, top: 430, width: 880 }}>
        <Reveal t={since(e.card1)} y={50} preset="smooth">
          <GlassCard style={{ height: 170, display: "flex", alignItems: "center", gap: 36, padding: "0 44px" }}>
            <div style={{ width: 110, height: 110, borderRadius: 30, background: alpha(c.accent, 0.12), display: "flex", alignItems: "center", justifyContent: "center" }}>
              <AntennaIcon size={92} color={c.accent} />
            </div>
            <Words text="বিশেষ antenna" t={since(e.card1) + 4} per={4} size={60} weight={theme.weight.strong} align="flex-start" gap={18} />
          </GlassCard>
        </Reveal>
      </div>
      <div style={{ position: "absolute", left: 120, top: 640, width: 880 }}>
        <Reveal t={since(e.card2)} y={50} preset="smooth">
          <GlassCard style={{ height: 210, display: "flex", alignItems: "center", gap: 36, padding: "0 44px" }}>
            <div style={{ width: 110, height: 110, flex: "none", borderRadius: 30, background: alpha(c.accent, 0.12), display: "flex", alignItems: "center", justifyContent: "center" }}>
              <ChipIcon size={92} color={c.accent} />
            </div>
            <Words text="নেটওয়ার্ক পরিচালনার ইলেকট্রনিক ব্যবস্থা" t={since(e.card2) + 4} per={3} size={52} weight={theme.weight.strong} align="flex-start" gap={16} />
          </GlassCard>
        </Reveal>
      </div>
    </AbsoluteFill>
  );
};
