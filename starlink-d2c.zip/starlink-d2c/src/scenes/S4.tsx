// Scene 4 · Dark Tech — স্যাটেলাইটের ভেতরে eNodeB modem
import React from "react";
import { AbsoluteFill } from "remotion";
import { E } from "../events";
import { alpha, theme } from "../theme";
import { ChipIcon, Pulses } from "../lib/art";
import { At, Chip, LineMask, Reveal, breathe, floatY, useAnim } from "../lib/ui";

const c = theme.colors;

// satellite cut-away geometry (canvas coordinates)
const BODY = { x: 600, y: 250, w: 720, h: 500 };
const CHIP = { cx: 960, cy: 470, w: 330, h: 230 };
const TRACES: { d: string; len: number; x: number; y: number }[] = [
  { d: "M795 470 H670", len: 125, x: 670, y: 470 },
  { d: "M1125 470 H1250", len: 125, x: 1250, y: 470 },
  { d: "M960 355 V300", len: 55, x: 960, y: 300 },
  { d: "M870 585 V690 H700", len: 275, x: 700, y: 690 },
  { d: "M1050 585 V690 H1220", len: 265, x: 1220, y: 690 },
];

export const S4: React.FC = () => {
  const { frame, since, tween, spr } = useAnim();
  const e = E.s4;
  const bodyT = since(e.body);
  const chipT = since(e.chip);
  const arcsT = since(e.arcs);
  const bodyP = spr(bodyT, "smooth");
  const panelP = (k: number) => spr(bodyT - 6 - k * 6, "smooth");
  const chipP = spr(chipT, "bouncy");

  return (
    <AbsoluteFill>
      <At x={120} y={70} w={900} align="flex-start">
        <Chip text="Starlink-এর ভাষায়" t={since(e.kicker)} size={46} />
      </At>

      <div style={{ position: "absolute", inset: 0, transform: "translateY(46px)" }}>
      <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: floatY(frame, 6, 130), overflow: "visible" }}>
        <defs>
          <linearGradient id="panelFill" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor={alpha(c.accent, 0.28)} />
            <stop offset="1" stopColor={alpha(c.accent, 0.04)} />
          </linearGradient>
          <linearGradient id="bodyFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={alpha(c.surfaceHi, 0.95)} />
            <stop offset="1" stopColor={alpha(c.surface, 0.95)} />
          </linearGradient>
        </defs>

        {/* solar panels */}
        {[0, 1].map((side) => {
          const x = side === 0 ? 110 : 1410;
          const p = panelP(side);
          return (
            <g key={side} opacity={Math.min(1, p * 1.4)} transform={`translate(${(side === 0 ? -1 : 1) * (1 - p) * 120} 0)`}>
              <rect x={x} y={375} width={400} height={250} rx={18} fill="url(#panelFill)" stroke={alpha(c.accent, 0.85)} strokeWidth={3} />
              {[1, 2, 3].map((i) => (
                <path key={i} d={`M${x + i * 100} 375 V625`} stroke={alpha(c.accent, 0.4)} strokeWidth={2} />
              ))}
              <path d={`M${x} 500 H${x + 400}`} stroke={alpha(c.accent, 0.4)} strokeWidth={2} />
              <path d={side === 0 ? "M510 500 H600" : "M1320 500 H1410"} stroke={c.text} strokeWidth={theme.stroke} strokeLinecap="round" />
            </g>
          );
        })}

        {/* mast */}
        <g opacity={Math.min(1, bodyP * 1.4)}>
          <path d="M960 250 V180" stroke={c.text} strokeWidth={theme.stroke} strokeLinecap="round" />
          <circle cx={960} cy={166} r={14} fill={c.text} />
        </g>

        {/* body */}
        <g opacity={Math.min(1, bodyP * 1.4)} transform={`translate(0 ${(1 - bodyP) * 40})`}>
          <rect x={BODY.x} y={BODY.y} width={BODY.w} height={BODY.h} rx={48} fill="url(#bodyFill)" stroke={alpha(c.text, 0.55)} strokeWidth={theme.stroke} />
          <rect x={BODY.x + 22} y={BODY.y + 22} width={BODY.w - 44} height={BODY.h - 44} rx={32} fill="none" stroke={alpha(c.text, 0.1)} strokeWidth={2} strokeDasharray="4 12" />
        </g>

        {/* circuit traces, drawn in staggered, with travelling dots */}
        {TRACES.map((tr, i) => {
          const t = since(e.kicker) + 14 + i * 7;
          const draw = tween(t, 0.7, 0, 1);
          const dash = tr.len;
          return (
            <g key={i} opacity={draw}>
              <path d={tr.d} fill="none" stroke={alpha(c.accent, 0.5)} strokeWidth={3} strokeLinecap="round" strokeDasharray={dash} strokeDashoffset={dash * (1 - draw)} />
              <circle cx={tr.x} cy={tr.y} r={7} fill={c.accent} />
            </g>
          );
        })}

        {/* chip */}
        <g
          opacity={Math.min(1, chipP * 1.5)}
          transform={`translate(${CHIP.cx} ${CHIP.cy}) scale(${0.7 + 0.3 * chipP}) translate(${-CHIP.cx} ${-CHIP.cy})`}
        >
          <rect
            x={CHIP.cx - CHIP.w / 2} y={CHIP.cy - CHIP.h / 2} width={CHIP.w} height={CHIP.h} rx={36}
            fill={alpha(c.primary, 0.2)} stroke={c.primary} strokeWidth={4}
            style={{ filter: `drop-shadow(0 0 28px ${alpha(c.primary, 0.55)})` }}
          />
        </g>
      </svg>

      {/* chip icon + label (HTML so Bangla/Latin text shapes properly) */}
      <div
        style={{
          position: "absolute", left: CHIP.cx - 55, top: CHIP.cy - 100 + floatY(frame, 6, 130),
          opacity: Math.min(1, spr(chipT, "bouncy") * 1.5), transform: `scale(${0.7 + 0.3 * spr(chipT, "bouncy")})`,
        }}
      >
        <ChipIcon size={110} color={c.text} />
      </div>
      <At x={960} y={CHIP.cy + 14 + floatY(frame, 6, 130)} w={600}>
        <Reveal t={chipT + 4} y={20} preset="snappy">
          <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 56, lineHeight: theme.lineHeight, color: c.text }}>
            eNodeB modem
          </div>
        </Reveal>
      </At>

      {arcsT > 0 && <Pulses cx={960} cy={166 + floatY(frame, 6, 130)} t={arcsT} a0={-160} a1={-20} minR={40} maxR={150} count={3} period={70} sw={4} />}
      </div>

      {/* statement */}
      <At x={960} y={845} w={1500}>
        <div style={{ transform: `scale(${breathe(frame, 0.008, 140)})` }}>
          <LineMask text="মহাকাশে টাওয়ারের মতো" t={since(e.statement)} size={92} />
        </div>
      </At>
    </AbsoluteFill>
  );
};
