// Scene 2 · Kinetic Typography — "নেটওয়ার্ক নেই" → Direct-to-Cell → Starlink
import React from "react";
import { AbsoluteFill } from "remotion";
import { E } from "../events";
import { alpha, theme } from "../theme";
import { Phone, Satellite, CrossIcon } from "../lib/art";
import { At, Chip, GradientText, LineMask, Reveal, Words, floatY, useAnim } from "../lib/ui";

const c = theme.colors;
const CX = 960, CY = 560;
const TILT = -12;

export const S2: React.FC = () => {
  const { frame, since, tween, spr } = useAnim();
  const e = E.s2;

  // phase A (statement) leaves as phase B lands
  const tB = since(e.d2c);
  const aO = 1 - tween(tB, 0.25, 0, 1, theme.ease.in);
  const aS = tween(tB, 0.25, 1, 0.92, theme.ease.in);
  const strike = tween(since(e.statement) - 8, 0.45, 0, 1);

  // orbit
  const orbitIn = tween(tB, 0.8, 0, 1);
  const rx = 800, ry = 250;
  const th = -0.9 + frame * 0.016;
  const sx = rx * Math.cos(th), sy = ry * Math.sin(th);
  const rot = (x: number, y: number) => {
    const a = (TILT * Math.PI) / 180;
    return [CX + x * Math.cos(a) - y * Math.sin(a), CY + x * Math.sin(a) + y * Math.cos(a)];
  };
  const [ox, oy] = rot(sx, sy);
  const behind = Math.sin(th) < 0; // upper half of ellipse = behind the text

  return (
    <AbsoluteFill>
      {/* ── phase A: no network ── */}
      <div style={{ opacity: aO, transform: `scale(${aS})`, position: "absolute", inset: 0 }}>
        <div style={{ position: "absolute", left: 470, top: 270 + floatY(frame, 5, 100) }}>
          <Reveal t={since(e.statement)} y={50} preset="bouncy" scale={0.85}>
            <Phone w={210} bars={0}>
              <CrossIcon size={84} color={c.text} />
            </Phone>
          </Reveal>
        </div>
        <At x={1290} y={440} w={800}>
          <div style={{ position: "relative" }}>
            <Words text="নেটওয়ার্ক নেই" t={since(e.statement) + 2} per={5} size={150} color={c.text} />
            <div
              style={{
                position: "absolute", left: 0, right: 0, top: "56%", height: 7, borderRadius: 7,
                background: c.primary, transformOrigin: "0% 50%", transform: `scaleX(${strike})`,
                boxShadow: theme.shadow.glow(c.primary),
              }}
            />
          </div>
        </At>
      </div>

      {/* ── phase B: Direct-to-Cell ── */}
      <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: 0, opacity: orbitIn }}>
        <g transform={`rotate(${TILT} ${CX} ${CY})`} fill="none">
          <ellipse cx={CX} cy={CY} rx={rx} ry={ry} stroke={alpha(c.text, 0.14)} strokeWidth={2} />
          <ellipse cx={CX} cy={CY} rx={rx * 0.72} ry={ry * 0.7} stroke={alpha(c.text, 0.08)} strokeWidth={2} strokeDasharray="6 14" />
        </g>
      </svg>
      {tB > -4 && behind && (
        <div style={{ position: "absolute", left: ox - 60, top: oy - 43, opacity: orbitIn * 0.8, transform: `rotate(${TILT}deg)` }}>
          <Satellite w={120} />
        </div>
      )}

      {tB > -4 && (
        <>
          <At x={CX} y={330} w={1800}>
            <Reveal t={tB} y={70} scale={0.9} preset="smooth">
              <GradientText size={196}>Direct-to-Cell</GradientText>
            </Reveal>
          </At>
          <At x={CX} y={590} w={1200}>
            <LineMask text="প্রযুক্তি" t={since(e.sub)} size={92} weight={theme.weight.strong} color={c.textDim} />
          </At>
          <At x={CX} y={780} w={1000}>
            <div style={{ display: "flex", alignItems: "center", gap: 28 }}>
              <Reveal t={since(e.starlink)} x={-60} y={0} preset="bouncy" scale={0.7}>
                <Satellite w={150} />
              </Reveal>
              <Chip text="Starlink" t={since(e.starlink) + 3} hero size={64} dot={false} />
            </div>
          </At>
        </>
      )}
      {tB > -4 && !behind && (
        <div style={{ position: "absolute", left: ox - 60, top: oy - 43, opacity: orbitIn * 0.95, transform: `rotate(${TILT}deg)` }}>
          <Satellite w={120} />
        </div>
      )}
    </AbsoluteFill>
  );
};
