// Scene 6 · Before/After Split — মূল বিষয়: ফোনে বিশাল antenna লাগে না
import React from "react";
import { AbsoluteFill } from "remotion";
import { E } from "../events";
import { alpha, theme } from "../theme";
import { AntennaIcon, CheckIcon, CrossIcon, Phone, Satellite } from "../lib/art";
import { At, Chip, GlassCard, LineMask, Reveal, Words, breathe, floatY, useAnim } from "../lib/ui";

const c = theme.colors;
const LANE_PUSH = 1180, LANE_PULL = 1330;
const SAT = { x: 1255, y: 100, w: 400 };
const PHONE = { x: 1255, top: 590, w: 210 };

export const S6: React.FC = () => {
  const { frame, since, tween, spr } = useAnim();
  const e = E.s6;

  const tSplit = since(e.split);
  const aO = 1 - tween(tSplit, 0.3, 0, 1, theme.ease.in);
  const aY = tween(tSplit, 0.3, 0, -30, theme.ease.in);
  const pushT = since(e.push);
  const pullT = since(e.pull);

  const flow = (t: number, up: boolean) =>
    [0, 1, 2].map((i) => {
      const k = (((t * 0.014 + i / 3) % 1) + 1) % 1;
      const y = up ? 560 - k * 130 : 430 + k * 130;
      const o = Math.sin(Math.PI * k) * Math.min(1, t / 6);
      return { y, o };
    });

  return (
    <AbsoluteFill>
      {/* ── phase A: phone ↔ satellite, key-message caption ── */}
      <div style={{ position: "absolute", inset: 0, opacity: aO, transform: `translateY(${aY}px)` }}>
        <div style={{ position: "absolute", left: SAT.x - SAT.w / 2, top: SAT.y + floatY(frame, 7, 120) }}>
          <Reveal t={since(e.pair)} y={-60} preset="smooth" scale={0.85}>
            <div style={{ transform: `rotate(-8deg) scale(${breathe(frame, 0.012, 130)})` }}>
              <Satellite w={SAT.w} bodyGlow />
            </div>
          </Reveal>
        </div>
        <div style={{ position: "absolute", left: PHONE.x - PHONE.w / 2, top: PHONE.top + floatY(frame, 5, 100, 30) }}>
          <Reveal t={since(e.pair) + 6} y={70} preset="smooth" scale={0.9}>
            <Phone w={PHONE.w} bars={4} />
          </Reveal>
        </div>

        <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: 0 }}>
          <path d={`M${LANE_PUSH} 570 V440`} stroke={alpha(c.accent, 0.25)} strokeWidth={3} strokeDasharray="4 12" strokeLinecap="round" opacity={tween(pushT, 0.4, 0, 1)} />
          <path d={`M${LANE_PULL} 440 V570`} stroke={alpha(c.accent, 0.25)} strokeWidth={3} strokeDasharray="4 12" strokeLinecap="round" opacity={tween(pullT, 0.4, 0, 1)} />
          {pushT > 0 && flow(pushT, true).map((p, i) => <circle key={`u${i}`} cx={LANE_PUSH} cy={p.y} r={9} fill={c.accent} opacity={p.o} />)}
          {pullT > 0 && flow(pullT, false).map((p, i) => <circle key={`d${i}`} cx={LANE_PULL} cy={p.y} r={9} fill={c.text} opacity={p.o} />)}
        </svg>
        <At x={LANE_PUSH - 40} y={470} w={380} align="flex-end">
          <Chip text="পাঠায়" t={pushT} size={42} />
        </At>
        <At x={LANE_PULL + 40} y={470} w={420} align="flex-start">
          <Chip text="গ্রহণ করে" t={pullT} size={42} />
        </At>

        <At x={120} y={250} w={800} align="flex-start">
          <Chip text="মূল বিষয়" t={since(e.key)} hero size={50} />
        </At>
        <At x={120} y={380} w={820} align="flex-start">
          <Words text="ফোনকে স্যাটেলাইটের সঙ্গে যোগাযোগ" t={since(e.caption)} per={5} size={84} align="flex-start" gap={24} hl={["যোগাযোগ"]} />
        </At>
      </div>

      {/* ── phase B: split — before / after ── */}
      {tSplit > -4 && (
        <>
          <Pane x={120} t={tSplit} no />
          <Pane x={1000} t={tSplit + 8} />
          {/* left: huge antenna on the phone */}
          <PaneBody x={120} t={since(e.big)} big done={since(e.no)} />
          <PaneBody x={1000} t={since(e.big) + 4} done={since(e.no)} />
        </>
      )}
    </AbsoluteFill>
  );
};

const PW = 800, PT = 170, PH = 740;

const Pane: React.FC<{ x: number; t: number; no?: boolean }> = ({ x, t }) => (
  <div style={{ position: "absolute", left: x, top: PT, width: PW, height: PH }}>
    <Reveal t={t} y={60} preset="smooth" scale={0.96}>
      <GlassCard style={{ width: PW, height: PH }} />
    </Reveal>
  </div>
);

const PaneBody: React.FC<{ x: number; t: number; big?: boolean; done: number }> = ({ x, t, big = false, done }) => {
  const { frame, spr, tween } = useAnim();
  const p = spr(t, "smooth");
  const badge = spr(done - (big ? 0 : 8), "bouncy");
  const dimLeft = big ? 1 - 0.55 * tween(done, 0.4, 0, 1) : 1;
  return (
    <div style={{ position: "absolute", left: x, top: PT, width: PW, height: PH, opacity: Math.min(1, p * 1.5) * dimLeft }}>
      {/* phone */}
      <div style={{ position: "absolute", left: PW / 2 - 95, top: 225 + floatY(frame, 5, 100), transform: `translateY(${(1 - p) * 40}px)` }}>
        <Phone w={190} bars={4} />
      </div>
      {/* big antenna on the left, small marker on the right */}
      {big ? (
        <div style={{ position: "absolute", left: PW / 2 - 165, top: -88, transform: `translateY(${(1 - p) * -60}px) scale(${0.85 + 0.15 * p})`, transformOrigin: "50% 100%" }}>
          <AntennaIcon size={330} color={c.text} sw={4} />
        </div>
      ) : (
        <div style={{ position: "absolute", left: PW / 2 + 60, top: 200 + floatY(frame, 5, 100), width: 22, height: 22, borderRadius: 22, background: c.accent, opacity: p }} />
      )}
      {/* label */}
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 28, display: "flex", justifyContent: "center" }}>
        <LineMask text={big ? "বিশাল antenna" : "লাগে না"} t={t + 6} size={70} color={big ? c.textDim : c.text} />
      </div>
      {/* badge */}
      <div
        style={{
          position: "absolute", left: PW - 150, top: 36, width: 100, height: 100, borderRadius: 100,
          display: "flex", alignItems: "center", justifyContent: "center",
          background: big ? alpha(c.text, 0.1) : alpha(c.primary, 0.9),
          border: big ? `3px solid ${alpha(c.text, 0.5)}` : `3px solid ${c.primary}`,
          boxShadow: big ? "none" : theme.shadow.glow(c.primary),
          transform: `scale(${0.4 + 0.6 * badge})`, opacity: Math.min(1, badge * 1.5),
        }}
      >
        {big ? <CrossIcon size={54} color={c.text} /> : <CheckIcon size={54} color={c.bg} />}
      </div>
    </div>
  );
};
