// Scene 7 · Bento / Checklist Recap Grid — স্যাটেলাইটের চার প্রযুক্তি + পরিষ্কার সমাপ্তি
import React from "react";
import { AbsoluteFill } from "remotion";
import { E } from "../events";
import { alpha, theme } from "../theme";
import { AntennaIcon, CheckIcon, ReceiverIcon, TransmitterIcon, WaveIcon } from "../lib/art";
import { At, Chip, GlassCard, Reveal, Words, floatY, useAnim } from "../lib/ui";

const c = theme.colors;

const ITEMS = [
  { bn: "বিশেষ", en: "antenna", Icon: AntennaIcon, key: "card1" },
  { bn: "সংবেদনশীল", en: "receiver", Icon: ReceiverIcon, key: "card2" },
  { bn: "শক্তিশালী", en: "transmitter", Icon: TransmitterIcon, key: "card3" },
  { bn: "উন্নত", en: "signal processing", Icon: WaveIcon, key: "card4" },
] as const;

const CARD_W = 400, GAP = 32, X0 = (1920 - (4 * CARD_W + 3 * GAP)) / 2;

export const S7: React.FC = () => {
  const { frame, since, spr, tween } = useAnim();
  const e = E.s7;
  const bannerT = since(e.banner);
  const bars = tween(bannerT, 1.0, 1, 4);

  return (
    <AbsoluteFill>
      <At x={X0} y={52} w={1200} align="flex-start">
        <Words text="স্যাটেলাইটের ভেতরে" t={since(e.title)} per={5} size={88} align="flex-start" hl={["স্যাটেলাইটের"]} />
      </At>

      {ITEMS.map((it, i) => {
        const t = since(e[it.key]);
        const check = spr(t - 14, "bouncy");
        return (
          <div key={it.key} style={{ position: "absolute", left: X0 + i * (CARD_W + GAP), top: 232 + floatY(frame, 4, 110, i * 20), width: CARD_W }}>
            <Reveal t={t} y={60} preset="smooth" scale={0.94}>
              <GlassCard style={{ height: 404, padding: "36px 30px", display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
                <div style={{ width: 150, height: 150, borderRadius: 38, background: alpha(c.accent, 0.12), display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <it.Icon size={112} color={c.accent} />
                </div>
                <div style={{ marginTop: 30, fontFamily: theme.fonts.display, fontSize: 48, fontWeight: theme.weight.strong, lineHeight: theme.lineHeight, color: c.textDim }}>
                  {it.bn}
                </div>
                <div style={{ fontFamily: theme.fonts.display, fontSize: 56, fontWeight: theme.weight.display, lineHeight: 1.15, color: c.text }}>
                  {it.en}
                </div>
                <div
                  style={{
                    position: "absolute", right: 26, top: 26, width: 64, height: 64, borderRadius: 64,
                    background: alpha(c.accent, 0.16), border: `2px solid ${alpha(c.accent, 0.7)}`,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    transform: `scale(${0.4 + 0.6 * check})`, opacity: Math.min(1, check * 1.5),
                  }}
                >
                  <CheckIcon size={34} color={c.accent} sw={6} />
                </div>
              </GlassCard>
            </Reveal>
          </div>
        );
      })}

      {/* result banner */}
      <div style={{ position: "absolute", left: X0, top: 664, width: 4 * CARD_W + 3 * GAP }}>
        <Reveal t={bannerT} y={50} preset="smooth" scale={0.97}>
          <GlassCard hero style={{ height: 190, display: "flex", alignItems: "center", gap: 44, padding: "0 56px" }}>
            <svg width={120} height={96} viewBox="0 0 120 96">
              {[0, 1, 2, 3].map((i) => {
                const lit = Math.max(0, Math.min(1, bars - i));
                const h = 24 + i * 20;
                return <rect key={i} x={i * 32} y={96 - h} width={20} height={h} rx={6} fill={lit > 0.02 ? c.primary : alpha(c.text, 0.18)} opacity={lit > 0.02 ? 0.4 + 0.6 * lit : 1} />;
              })}
            </svg>
            <Words text="দুর্বল সিগন্যালের চ্যালেঞ্জ সামলায়" t={bannerT + 4} per={4} size={74} align="flex-start" gap={22} />
          </GlassCard>
        </Reveal>
      </div>

      {/* clean sign-off */}
      <At x={960} y={920} w={1200}>
        <Chip text="Direct-to-Cell · Starlink" t={since(e.end)} dot={false} size={44} />
      </At>
    </AbsoluteFill>
  );
};
