import React, { useEffect, useState } from "react";
import { Audio, getRemotionEnvironment, staticFile } from "remotion";
import { PREVIEW_AUDIO } from "./config";

/** Plays public/voiceover.mp3 in Studio preview if it exists; otherwise renders nothing. */
export const PreviewAudio: React.FC = () => {
  const [available, setAvailable] = useState(false);
  const skip =
    !PREVIEW_AUDIO.enabled || (getRemotionEnvironment().isRendering && !PREVIEW_AUDIO.includeInRender);

  useEffect(() => {
    if (skip) return;
    const ctrl = new AbortController();
    fetch(staticFile(PREVIEW_AUDIO.src), { signal: ctrl.signal })
      .then((res) => {
        const type = res.headers.get("content-type") ?? "";
        if (res.ok && (type.startsWith("audio") || type.includes("mpeg") || type.includes("octet-stream"))) {
          setAvailable(true);
        }
        ctrl.abort(); // headers are enough, don't download the whole file twice
      })
      .catch(() => undefined);
    return () => ctrl.abort();
  }, [skip]);

  if (skip || !available) return null;
  return <Audio src={staticFile(PREVIEW_AUDIO.src)} volume={PREVIEW_AUDIO.volume} />;
};
