// events.ts — absolute-frame timing of every on-screen event, all derived from the SRT.
// Scenes and the SFX track both read from here, so picture and sound can never drift apart.
import { cueIn, evenly, show } from "./timeline";

export const E = {
  s1: {
    title: show(1, "সাধারণ"),
    ground: show(1, "নেটওয়ার্কে"),
    phone: show(1, "ফোন"),
    tower: show(1, "টাওয়ার"),
    link: show(1, "রেডিও"),
    breakUp: show(2, "কিন্তু"),
    noTower: show(2, "টাওয়ার নেই"),
  },
  s2: {
    statement: cueIn(3),
    d2c: show(3, "Direct-to-Cell"),
    sub: show(3, "প্রযুক্তিতে"),
    starlink: show(3, "Starlink"),
  },
  s3: {
    sat: cueIn(4),
    title: show(4, "মহাকাশে"),
    beam: show(4, "টাওয়ারের"),
    card1: show(5, "বিশেষ antenna"),
    card2: show(5, "মোবাইল নেটওয়ার্ক পরিচালনার"),
  },
  s4: {
    body: cueIn(6),
    kicker: show(6, "Starlink"),
    chip: show(6, "eNodeB"),
    statement: show(7, "মহাকাশে"),
    arcs: show(7, "টাওয়ারের"),
  },
  s5: {
    phone: cueIn(8),
    lens: show(8, "ছোট"),
    label: show(8, "সেলুলার"),
    radio: show(8, "রেডিও"),
  },
  s6: {
    pair: cueIn(9),
    push: show(9, "পাঠায়"),
    pull: show(9, "গ্রহণ"),
    key: show(9, "মূল বিষয়"),
    caption: show(9, "ফোনকে"),
    split: show(10, "ফোনের ভিতরে"),
    big: show(10, "বিশাল"),
    no: show(10, "দরকার হয় না"),
  },
  s7: {
    title: cueIn(11),
    card1: evenly(11, 3, 0), // antenna       ┐ three items named inside cue 11
    card2: evenly(11, 3, 1), // receiver      │ → shown at equal spacing across the cue
    card3: evenly(11, 3, 2), // transmitter   ┘
    card4: show(12, "signal processing"),
    banner: show(12, "চ্যালেঞ্জ"),
    end: cueIn(13),
  },
} as const;
