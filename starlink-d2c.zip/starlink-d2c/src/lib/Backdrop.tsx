import React from "react";
import { AbsoluteFill } from "remotion";
import { useAnim } from "./ui";
import { alpha, theme } from "../theme";

const c = theme.colors;

// deterministic star field (no Math.random → identical on every render)
const stars = (() => {
  let s = 20261021;
  const r = () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
  return Array.from({ length: 110 }, () => ({
    x: r() * 1920,
    y: r() * 1080,
    r: 0.8 + r() * 1.9,
    ph: r() * Math.PI * 2,
    sp: 0.02 + r() * 0.05,
    base: 0.25 + r() * 0.5,
  }));
})();

/** layer 1 — background mesh + slow star drift. Never a flat colour. */
export const BgMesh: React.FC = () => {
  const { frame } = useAnim();
  const d1 = Math.sin(frame / 55) * 60;
  const d2 = Math.cos(frame / 70) * 50;
  return (
    <AbsoluteFill style={{ background: `linear-gradient(180deg, ${c.bg} 0%, ${c.bgAlt} 100%)` }}>
      <div
        style={{
          position: "absolute", width: 1300, height: 1300, borderRadius: "50%",
          top: -560, left: -380 + d1, filter: "blur(60px)",
          background: `radial-gradient(circle, ${alpha(c.primary, 0.26)}, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute", width: 1000, height: 1000, borderRadius: "50%",
          bottom: -480, right: -300 - d2, filter: "blur(70px)",
          background: `radial-gradient(circle, ${alpha(c.accent, 0.16)}, transparent 65%)`,
        }}
      />
      <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: 0 }}>
        {stars.map((st, i) => (
          <circle
            key={i}
            cx={(st.x - frame * 0.12 * (0.4 + st.r / 2) + 1920 * 4) % 1920}
            cy={st.y}
            r={st.r}
            fill={c.text}
            opacity={st.base * (0.55 + 0.45 * Math.sin(frame * st.sp + st.ph))}
          />
        ))}
      </svg>
    </AbsoluteFill>
  );
};

/** layer 4 — colour grade above all content */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: c.primary, mixBlendMode: "soft-light", opacity: 0.16 }} />
    <AbsoluteFill
      style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 26%, transparent 74%, rgba(0,0,0,0.22))" }}
    />
  </AbsoluteFill>
);

/** layer 5a — procedural film grain (no asset file) */
export const Grain: React.FC = () => {
  const { frame } = useAnim();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.06,
        mixBlendMode: "overlay",
      }}
    />
  );
};

/** layer 5b — vignette, topmost */
export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 56%, rgba(0,0,0,0.3) 100%)" }}
  />
);
