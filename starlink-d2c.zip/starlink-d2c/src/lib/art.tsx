import React, { useId } from "react";
import { alpha, theme } from "../theme";

const c = theme.colors;
const SW = theme.stroke;

// ───────────────────────── geometry helpers ─────────────────────────
const rad = (d: number) => (d * Math.PI) / 180;
/** SVG arc path; angles in degrees, 0° = +x, clockwise on screen */
export const arcPath = (cx: number, cy: number, r: number, a0: number, a1: number) => {
  const x0 = cx + r * Math.cos(rad(a0));
  const y0 = cy + r * Math.sin(rad(a0));
  const x1 = cx + r * Math.cos(rad(a1));
  const y1 = cy + r * Math.sin(rad(a1));
  const large = Math.abs(a1 - a0) > 180 ? 1 : 0;
  const sweep = a1 > a0 ? 1 : 0;
  return `M${x0.toFixed(2)} ${y0.toFixed(2)} A${r} ${r} 0 ${large} ${sweep} ${x1.toFixed(2)} ${y1.toFixed(2)}`;
};
export const quad = (p0: [number, number], p1: [number, number], p2: [number, number], t: number): [number, number] => [
  (1 - t) * (1 - t) * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0],
  (1 - t) * (1 - t) * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1],
];

type IconProps = { size?: number; color?: string; style?: React.CSSProperties; sw?: number };
const svgBase = (size: number, vb: string, style?: React.CSSProperties) => ({
  width: size,
  height: size,
  viewBox: vb,
  fill: "none",
  style: { overflow: "visible", ...style },
});
const strokeProps = (color: string, sw: number) => ({
  stroke: color,
  strokeWidth: sw,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
});

// ───────────────────────── line icons (viewBox 120) ─────────────────────────
export const AntennaIcon: React.FC<IconProps> = ({ size = 120, color = c.text, sw = SW, style }) => (
  <svg {...svgBase(size, "0 0 120 120", style)}>
    <g {...strokeProps(color, sw)}>
      <path d="M60 48 V106" />
      <path d="M60 78 H72 M60 92 H72" opacity={0.6} />
      <path d="M38 110 H82" />
      <circle cx="60" cy="38" r="7" fill={color} />
      <path d={arcPath(60, 38, 22, -135, -45)} />
      <path d={arcPath(60, 38, 38, -135, -45)} opacity={0.65} />
      <path d={arcPath(60, 38, 22, 45, 135)} />
      <path d={arcPath(60, 38, 38, 45, 135)} opacity={0.65} />
    </g>
  </svg>
);

export const ReceiverIcon: React.FC<IconProps> = ({ size = 120, color = c.text, sw = SW, style }) => (
  <svg {...svgBase(size, "0 0 120 120", style)}>
    <g {...strokeProps(color, sw)}>
      <circle cx="84" cy="60" r="8" fill={color} />
      <path d={arcPath(84, 60, 26, 140, 220)} />
      <path d={arcPath(84, 60, 44, 140, 220)} opacity={0.7} />
      <path d={arcPath(84, 60, 62, 140, 220)} opacity={0.4} />
      <path d="M84 70 V104" />
    </g>
  </svg>
);

export const TransmitterIcon: React.FC<IconProps> = ({ size = 120, color = c.text, sw = SW, style }) => (
  <svg {...svgBase(size, "0 0 120 120", style)}>
    <g {...strokeProps(color, sw)}>
      <circle cx="36" cy="60" r="8" fill={color} />
      <path d={arcPath(36, 60, 26, -40, 40)} />
      <path d={arcPath(36, 60, 44, -40, 40)} opacity={0.7} />
      <path d={arcPath(36, 60, 62, -40, 40)} opacity={0.4} />
      <path d="M36 70 V104" />
    </g>
  </svg>
);

export const WaveIcon: React.FC<IconProps> = ({ size = 120, color = c.text, sw = SW, style }) => (
  <svg {...svgBase(size, "0 0 120 120", style)}>
    <g {...strokeProps(color, sw)}>
      <rect x="10" y="20" width="100" height="80" rx="20" />
      <path d="M22 62 H38 L46 38 L58 86 L70 44 L78 62 H98" />
    </g>
  </svg>
);

export const ChipIcon: React.FC<IconProps> = ({ size = 120, color = c.text, sw = SW, style }) => (
  <svg {...svgBase(size, "0 0 120 120", style)}>
    <g {...strokeProps(color, sw)}>
      <rect x="30" y="30" width="60" height="60" rx="12" />
      <rect x="46" y="46" width="28" height="28" rx="6" />
      {[44, 60, 76].map((p) => (
        <g key={p}>
          <path d={`M${p} 30 V14`} />
          <path d={`M${p} 90 V106`} />
          <path d={`M30 ${p} H14`} />
          <path d={`M90 ${p} H106`} />
        </g>
      ))}
    </g>
  </svg>
);

export const CheckIcon: React.FC<IconProps> = ({ size = 56, color = c.text, sw = 6, style }) => (
  <svg {...svgBase(size, "0 0 56 56", style)}>
    <path d="M10 30 L23 43 L47 13" {...strokeProps(color, sw)} />
  </svg>
);
export const CrossIcon: React.FC<IconProps> = ({ size = 56, color = c.text, sw = 6, style }) => (
  <svg {...svgBase(size, "0 0 56 56", style)}>
    <path d="M12 12 L44 44 M44 12 L12 44" {...strokeProps(color, sw)} />
  </svg>
);

// ───────────────────────── phone ─────────────────────────
/** Generic smartphone. `bars` 0–4 (fractional = partial). Children render inside the screen. */
export const Phone: React.FC<{
  w?: number;
  bars?: number;
  barColor?: string;
  dim?: number; // 0–1 extra dimming of the whole body
  children?: React.ReactNode;
  style?: React.CSSProperties;
}> = ({ w = 260, bars = 4, barColor = c.text, dim = 0, children, style }) => {
  const id = useId().replace(/:/g, "");
  const h = w * 2;
  return (
    <div style={{ position: "relative", width: w, height: h, opacity: 1 - dim * 0.6, ...style }}>
      <svg width={w} height={h} viewBox="0 0 260 520" style={{ position: "absolute", inset: 0, overflow: "visible" }}>
        <defs>
          <linearGradient id={`b${id}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor={c.surfaceHi} />
            <stop offset="1" stopColor={c.surface} />
          </linearGradient>
          <linearGradient id={`s${id}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={c.bgAlt} />
            <stop offset="1" stopColor={c.bg} />
          </linearGradient>
        </defs>
        <rect x="2" y="2" width="256" height="516" rx="46" fill={`url(#b${id})`} stroke={alpha(c.text, 0.32)} strokeWidth="3" />
        <rect x="14" y="14" width="232" height="492" rx="36" fill={`url(#s${id})`} />
        <rect x="95" y="26" width="70" height="15" rx="7.5" fill={alpha(c.text, 0.16)} />
        {[0, 1, 2, 3].map((i) => {
          const lit = Math.max(0, Math.min(1, bars - i));
          const bh = 9 + i * 5;
          return (
            <rect
              key={i}
              x={170 + i * 15}
              y={78 - bh}
              width="9"
              height={bh}
              rx="3"
              fill={lit > 0.02 ? barColor : alpha(c.text, 0.16)}
              opacity={lit > 0.02 ? 0.35 + 0.65 * lit : 1}
            />
          );
        })}
      </svg>
      <div
        style={{
          position: "absolute",
          left: (14 / 260) * w,
          top: (90 / 520) * h,
          width: (232 / 260) * w,
          height: (400 / 520) * h,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {children}
      </div>
    </div>
  );
};

// ───────────────────────── mobile tower ─────────────────────────
/** lattice tower; `pulse` 0–1 drives the two radio arcs on each side */
export const Tower: React.FC<{ w?: number; pulse?: number; color?: string; style?: React.CSSProperties }> = ({
  w = 200,
  pulse = 1,
  color = c.text,
  style,
}) => {
  const h = (w * 320) / 200;
  const dim = alpha(color, 0.55);
  return (
    <svg width={w} height={h} viewBox="0 0 200 320" fill="none" style={{ overflow: "visible", ...style }}>
      <g {...strokeProps(dim, SW)}>
        <path d="M100 60 L48 308 M100 60 L152 308 M28 308 H172" />
        <path d="M85.3 130 H114.7 M72.7 190 H127.3 M60.1 250 H139.9" />
        <path d="M85.3 130 L127.3 190 M114.7 130 L72.7 190 M72.7 190 L139.9 250 M127.3 190 L60.1 250" />
      </g>
      <circle cx="100" cy="44" r="11" fill={color} />
      <g {...strokeProps(color, SW)}>
        <path d="M121.4 26 A28 28 0 0 1 121.4 62" opacity={pulse} />
        <path d="M133.7 15.7 A44 44 0 0 1 133.7 72.3" opacity={pulse * 0.6} />
        <path d="M78.6 26 A28 28 0 0 0 78.6 62" opacity={pulse} />
        <path d="M66.3 15.7 A44 44 0 0 0 66.3 72.3" opacity={pulse * 0.6} />
      </g>
    </svg>
  );
};

// ───────────────────────── satellite ─────────────────────────
export const Satellite: React.FC<{
  w?: number;
  color?: string;
  panel?: string;
  style?: React.CSSProperties;
  bodyGlow?: boolean;
}> = ({ w = 420, color = c.text, panel = c.accent, style, bodyGlow = false }) => {
  const id = useId().replace(/:/g, "");
  const h = (w * 300) / 420;
  return (
    <svg width={w} height={h} viewBox="0 0 420 300" fill="none" style={{ overflow: "visible", ...style }}>
      <defs>
        <linearGradient id={`p${id}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={alpha(panel, 0.32)} />
          <stop offset="1" stopColor={alpha(panel, 0.06)} />
        </linearGradient>
        <linearGradient id={`g${id}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={c.surfaceHi} />
          <stop offset="1" stopColor={c.surface} />
        </linearGradient>
      </defs>
      {/* solar panels */}
      {[20, 290].map((x) => (
        <g key={x}>
          <rect x={x} y="108" width="110" height="84" rx="8" fill={`url(#p${id})`} {...strokeProps(alpha(panel, 0.9), 3)} />
          <path d={`M${x + 27.5} 108 V192 M${x + 55} 108 V192 M${x + 82.5} 108 V192 M${x} 150 H${x + 110}`} {...strokeProps(alpha(panel, 0.5), 2)} />
        </g>
      ))}
      <path d="M130 150 H160 M260 150 H290" {...strokeProps(color, SW)} />
      {/* body */}
      <rect x="160" y="92" width="100" height="116" rx="20" fill={`url(#g${id})`} {...strokeProps(color, SW)} />
      {bodyGlow && <rect x="160" y="92" width="100" height="116" rx="20" fill={alpha(c.primary, 0.12)} />}
      <path d="M180 124 H240 M180 150 H240 M180 176 H220" {...strokeProps(alpha(color, 0.4), 3)} />
      {/* antenna + dish */}
      <path d="M210 92 V66" {...strokeProps(color, SW)} />
      <circle cx="210" cy="58" r="8" fill={color} />
      <path d="M210 208 V226" {...strokeProps(color, SW)} />
      <path d="M176 262 Q210 214 244 262" {...strokeProps(color, SW)} />
      <circle cx="210" cy="236" r="5" fill={color} />
    </svg>
  );
};

// ───────────────────────── radio pulses ─────────────────────────
/**
 * Expanding arc rings. Full-canvas SVG (1920×1080 coordinate space).
 * a0/a1 in degrees (0 = right, clockwise); omit for full circles.
 */
export const Pulses: React.FC<{
  cx: number;
  cy: number;
  t: number; // frames since start (negative = off)
  color?: string;
  count?: number;
  minR?: number;
  maxR?: number;
  a0?: number;
  a1?: number;
  period?: number; // frames per cycle
  sw?: number;
  strength?: number;
}> = ({ cx, cy, t, color = c.accent, count = 3, minR = 30, maxR = 220, a0, a1, period = 70, sw = 4, strength = 1 }) => {
  if (t < 0) return null;
  return (
    <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{ position: "absolute", left: 0, top: 0, pointerEvents: "none" }} fill="none">
      {Array.from({ length: count }).map((_, k) => {
        const ph = ((t / period + k / count) % 1 + 1) % 1;
        const e = theme.ease.out(ph);
        const r = minR + (maxR - minR) * e;
        const o = Math.pow(1 - ph, 1.4) * Math.min(1, t / 8) * strength;
        const p = a0 === undefined || a1 === undefined ? null : arcPath(cx, cy, r, a0, a1);
        return p ? (
          <path key={k} d={p} stroke={color} strokeWidth={sw} strokeLinecap="round" opacity={o} />
        ) : (
          <circle key={k} cx={cx} cy={cy} r={r} stroke={color} strokeWidth={sw} opacity={o} />
        );
      })}
    </svg>
  );
};
