import React, { createContext, useContext } from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { alpha, theme } from "../theme";

const c = theme.colors;

// ───────────────────────── scene context + animation hook ─────────────────────────
export const SceneCtx = createContext<{ from: number; duration: number }>({ from: 0, duration: 1 });

type SpringName = keyof typeof theme.spring;

/**
 * `since(absFrame)` = frames elapsed since an ABSOLUTE timeline frame (negative = not yet).
 * Every scene event is expressed as an absolute frame derived from the SRT (timeline.ts).
 */
export const useAnim = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { from, duration } = useContext(SceneCtx);
  const since = (abs: number) => frame - (abs - from);
  const spr = (t: number, preset: SpringName = "smooth") =>
    t < 0 ? 0 : spring({ frame: t, fps, config: theme.spring[preset] });
  /** eased tween over `sec` seconds, clamped on both sides */
  const tween = (
    t: number,
    sec: number,
    a: number,
    b: number,
    easing: (n: number) => number = theme.ease.out,
  ) =>
    interpolate(t, [0, Math.max(1, Math.round(sec * fps))], [a, b], {
      easing,
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    });
  const sec = (s: number) => Math.round(s * fps);
  return { frame, fps, from, duration, since, spr, tween, sec };
};

// idle breathing helpers (anything on screen > 2 s moves a little)
export const floatY = (frame: number, amp = 6, period = 90, phase = 0) =>
  Math.sin(((frame + phase) / period) * Math.PI * 2) * amp;
export const breathe = (frame: number, amp = 0.014, period = 110, phase = 0) =>
  1 + Math.sin(((frame + phase) / period) * Math.PI * 2) * amp;

// ───────────────────────── generic entrance ─────────────────────────
export const Reveal: React.FC<{
  t: number;
  y?: number;
  x?: number;
  scale?: number;
  preset?: SpringName;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({ t, y = 36, x = 0, scale = 0.94, preset = "smooth", style, children }) => {
  const { spr } = useAnim();
  const p = spr(t, preset);
  return (
    <div
      style={{
        opacity: Math.min(1, p * 1.4),
        transform: `translate(${(1 - p) * x}px, ${(1 - p) * y}px) scale(${scale + (1 - scale) * p})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

// ───────────────────────── text ─────────────────────────
const textBase = (size: number, weight: number, color: string): React.CSSProperties => ({
  fontFamily: theme.fonts.display,
  fontSize: size,
  fontWeight: weight,
  color,
  lineHeight: theme.lineHeight,
  letterSpacing: 0, // Bangla: never track out (breaks conjunct rhythm)
});

/**
 * Word-by-word staggered reveal. Splits ONLY on spaces (never inside a word),
 * so Bangla conjuncts, kar-marks and ref stay intact.
 */
export const Words: React.FC<{
  text: string;
  t: number;
  per?: number; // frames between words (3–6)
  size?: number;
  weight?: number;
  color?: string;
  hl?: string[]; // words to emphasise (hero colour + sweep pill)
  align?: "center" | "flex-start" | "flex-end";
  gap?: number; // px
  style?: React.CSSProperties;
}> = ({ text, t, per = 4, size = theme.size.title, weight = theme.weight.display, color = c.text, hl = [], align = "center", gap = 36, style }) => {
  const { spr, tween } = useAnim();
  const words = text.split(" ");
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: align,
        columnGap: gap,
        ...textBase(size, weight, color),
        ...style,
      }}
    >
      {words.map((w, i) => {
        const tw = t - i * per;
        const p = spr(tw, "snappy");
        const isHl = hl.includes(w);
        const sweep = tween(tw - 5, 0.4, 0, 1);
        return (
          <span
            key={i}
            style={{
              position: "relative",
              display: "inline-block",
              opacity: Math.min(1, p * 1.5),
              transform: `translateY(${(1 - p) * 34}px) scale(${0.9 + 0.1 * p})`,
              color: isHl ? c.primary : color,
            }}
          >
            {isHl && (
              <span
                style={{
                  position: "absolute",
                  left: "-0.22em",
                  right: "-0.22em",
                  top: "0.1em",
                  bottom: "0.05em",
                  borderRadius: "0.32em",
                  background: alpha(c.primary, 0.2),
                  transform: `scaleX(${sweep})`,
                  transformOrigin: "0% 50%",
                  zIndex: -1,
                }}
              />
            )}
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** line mask reveal: the line slides up from behind a clip (padded so matras never get cut) */
export const LineMask: React.FC<{
  text: string;
  t: number;
  size?: number;
  weight?: number;
  color?: string;
  align?: "center" | "left" | "right";
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ text, t, size = theme.size.heading, weight = theme.weight.display, color = c.text, align = "center", style, children }) => {
  const { tween } = useAnim();
  const y = tween(t, 0.6, 108, 0);
  const o = tween(t, 0.25, 0, 1);
  return (
    <div style={{ overflow: "hidden", padding: "0.26em 0.18em", margin: "-0.26em -0.18em", textAlign: align, ...style }}>
      <div style={{ ...textBase(size, weight, color), transform: `translateY(${y}%)`, opacity: o }}>
        {children ?? text}
      </div>
    </div>
  );
};

/** gradient keyword — padded so ascending/descending glyph parts are not clipped by background-clip */
export const GradientText: React.FC<{ children: React.ReactNode; size: number; weight?: number }> = ({
  children,
  size,
  weight = theme.weight.display,
}) => (
  <span
    style={{
      ...textBase(size, weight, c.text),
      display: "inline-block",
      padding: "0.2em 0.1em",
      margin: "-0.2em -0.1em",
      background: `linear-gradient(100deg, ${c.primary} 10%, ${c.accent} 90%)`,
      WebkitBackgroundClip: "text",
      backgroundClip: "text",
      WebkitTextFillColor: "transparent",
    }}
  >
    {children}
  </span>
);

// ───────────────────────── surfaces ─────────────────────────
export const GlassCard: React.FC<{
  style?: React.CSSProperties;
  hero?: boolean;
  children?: React.ReactNode;
}> = ({ style, hero = false, children }) => (
  <div
    style={{
      position: "relative",
      boxSizing: "border-box",
      borderRadius: theme.radius.card,
      background: `linear-gradient(150deg, ${alpha(c.text, 0.1)} 0%, ${alpha(c.text, 0.035)} 60%, ${alpha(c.surface, 0.7)} 100%)`,
      border: `1.5px solid ${hero ? alpha(c.primary, 0.7) : alpha(c.text, 0.14)}`,
      boxShadow: `${theme.shadow.card}, inset 0 1px 0 ${alpha(c.text, 0.14)}${hero ? `, ${theme.shadow.glow(c.primary)}` : ""}`,
      ...style,
    }}
  >
    {children}
  </div>
);

export const Chip: React.FC<{
  text: string;
  t: number;
  size?: number;
  hero?: boolean;
  dot?: boolean;
  style?: React.CSSProperties;
}> = ({ text, t, size = theme.size.small, hero = false, dot = true, style }) => (
  <Reveal t={t} y={18} scale={0.8} preset="bouncy" style={style}>
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 16,
        padding: "10px 30px 12px",
        borderRadius: theme.radius.pill,
        background: hero ? alpha(c.primary, 0.2) : alpha(c.surfaceHi, 0.9),
        border: `1.5px solid ${hero ? alpha(c.primary, 0.75) : alpha(c.text, 0.18)}`,
        boxShadow: hero ? theme.shadow.glow(c.primary) : "none",
        ...textBase(size, theme.weight.strong, c.text),
        whiteSpace: "nowrap",
      }}
    >
      {dot && <span style={{ width: 14, height: 14, borderRadius: 14, background: hero ? c.primary : c.accent }} />}
      {text}
    </div>
  </Reveal>
);

/** absolutely positioned box centred horizontally on x (canvas coordinates) */
export const At: React.FC<{
  x: number;
  y: number;
  w?: number;
  align?: "center" | "flex-start" | "flex-end";
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ x, y, w = 1000, align = "center", style, children }) => (
  <div
    style={{
      position: "absolute",
      left: align === "center" ? x - w / 2 : align === "flex-start" ? x : x - w,
      top: y,
      width: w,
      display: "flex",
      justifyContent: align,
      ...style,
    }}
  >
    {children}
  </div>
);
