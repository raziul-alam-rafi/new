import React from "react";
import { AbsoluteFill } from "remotion";
import { SceneCtx, useAnim } from "./ui";
import { theme } from "../theme";

/**
 * Scene wrapper: soft entrance (fade + rise + scale) and a faster exit (fade + lift + blur).
 * Scenes overlap by LEAD frames, so the outgoing scene dissolves while the next one lands.
 */
const Inner: React.FC<{ last: boolean; children: React.ReactNode }> = ({ last, children }) => {
  const { frame, duration, tween, sec } = useAnim();
  const inO = tween(frame, 0.25, 0, 1);
  const inY = tween(frame, 0.5, 26, 0);
  const inS = tween(frame, 0.5, 0.975, 1);
  const exitLen = 0.27; // faster than the ~0.5 s entrance
  const te = frame - (duration - sec(exitLen));
  const exO = last ? 1 : tween(te, exitLen, 1, 0, theme.ease.in);
  const exY = last ? 0 : tween(te, exitLen, 0, -24, theme.ease.in);
  const exS = last ? 1 : tween(te, exitLen, 1, 1.025, theme.ease.in);
  const blur = last ? 0 : tween(te, exitLen, 0, 5, theme.ease.in);
  return (
    <AbsoluteFill
      style={{
        opacity: inO * exO,
        transform: `translateY(${inY + exY}px) scale(${inS * exS})`,
        filter: blur > 0.05 ? `blur(${blur}px)` : undefined,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

export const SceneShell: React.FC<{ from: number; duration: number; last?: boolean; children: React.ReactNode }> = ({
  from,
  duration,
  last = false,
  children,
}) => (
  <SceneCtx.Provider value={{ from, duration }}>
    <Inner last={last}>{children}</Inner>
  </SceneCtx.Provider>
);
