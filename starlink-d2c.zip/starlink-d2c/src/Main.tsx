import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { PreviewAudio } from "./PreviewAudio";
import { SfxTrack } from "./SfxTrack";
import { SCENES } from "./timeline";
import { SCENE_COMPONENTS } from "./scenes";
import { SceneShell } from "./lib/SceneShell";
import { BgMesh, Grade, Grain, Vignette } from "./lib/Backdrop";
import { theme } from "./theme";

/**
 * Layer stack (bottom → top):
 *  1 background mesh + stars · 2–3 scene assets & graphics · 4 colour grade · 5 grain + vignette
 */
export const Main: React.FC = () => (
  <AbsoluteFill style={{ backgroundColor: theme.colors.bg }}>
    <BgMesh />
    {SCENES.map((s, i) => {
      const Scene = SCENE_COMPONENTS[s.id];
      return (
        <Sequence key={s.id} from={s.from} durationInFrames={s.duration} name={s.id}>
          <SceneShell from={s.from} duration={s.duration} last={i === SCENES.length - 1}>
            <Scene />
          </SceneShell>
        </Sequence>
      );
    })}
    <Grade />
    <Grain />
    <Vignette />
    <SfxTrack />
    <PreviewAudio />
  </AbsoluteFill>
);
