import React from "react";
import { Audio, Sequence, staticFile } from "remotion";
import { SFX, SFX_VOL, sfxDurationFrames } from "./sfx";

export const SfxTrack: React.FC = () => (
  <>
    {SFX.map((e, i) => (
      <Sequence key={i} from={e.f} durationInFrames={sfxDurationFrames(e)}>
        <Audio src={staticFile(`sfx/${e.kind}.wav`)} volume={e.vol ?? SFX_VOL[e.kind]} playbackRate={e.rate ?? 1} />
      </Sequence>
    ))}
  </>
);
